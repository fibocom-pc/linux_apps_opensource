sudo cp libcode.so /usr/lib
cmake -C . -B build
cmake build/
cd build/
make
