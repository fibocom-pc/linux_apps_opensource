#include <gio/gio.h>
#include <stdio.h>
#include "FibocomHelper.h"

helperComFibocomHelper *proxy;

static gchar at_command[5][64] = {
"AT+GTFCCEFFSTATUS?",
"AT+GTFCCLOCKGEN",
"AT+CGMR",
"ATI7",
"ATI8"
};
static gboolean modem_status_handler(helperComFibocomHelper *object, const char *value, gpointer userdata)
{
    printf("modem_status_handler invoked! %s \n",value);
    if(userdata == NULL)
    {
    	return TRUE;
    }
    else
    {
    	printf("[%s]:recive userdate :%s\n", (char *)userdata);
    }
}

static gboolean service_status_handler(helperComFibocomHelper *object, const char *value, gpointer userdata)
{
    printf("Revice signal : %s \n",value);
    //if(strcmp(value, "413c:8213") != 0)
    if(strcmp(value, "4d75") != 0)
    {
    	printf("[-------------------------------]Modem not exit!\n");
    	
    }
}
gpointer mythread(gpointer user_date)
{
    gchar callstring[128] = "";
    GError *callError = NULL;
    gint i = 0;
    gint j = 0;
    gchar *cstring=NULL;
    
    printf("[%s]:%s\n",__func__, (char *)user_date);
    //调用server方法
    do
    {
            sprintf(callstring,"Fibocom Helper v1.0, %d",i);
	    helper_com_fibocom_helper_call_set_version_sync(proxy,callstring,NULL,&callError);
	    if(callError == NULL)
	    {
		printf("call_set_version_sync success\n");
	        //printf("call_set_version_sync:%s\n",callstring);
	    }else
	    {
		printf("call_set_version_sync error, %s\n",callError->message);
	    }
	    
	    memset(callstring, 0, sizeof(callstring));
	    //cstring = &(callstring[0]);
	    if(j != 4)
	    {
	    	helper_com_fibocom_helper_call_get_version_sync(proxy,at_command[j],&cstring,NULL,&callError);
	    	j++;
	    }
	    else
	    {
	        j = 0;
	    }
	    
	    if(callError == NULL)
	    {
		printf("call_get_version_sync success:%s\n", cstring);
	    }else
	    {
		printf("call_get_version_sync error, %s\n",callError->message);
	    }
	    i++;
	    sleep(1);
    }while(1);
	
}
typedef struct atcommand
{
    const gchar command[128];
    gchar *atresp;
}atcommand;

gpointer processthread(atcommand *user_date)
{
    GError *callError = NULL;

    printf("[%s]:%s\n",__func__, (char *)user_date->command);
    //调用server方法
    do
    {
        helper_com_fibocom_helper_call_get_version_sync(proxy,user_date->command,&user_date->atresp,NULL,&callError);

        if(callError == NULL)
        {
            printf("[=============================]call_get_version_sync success:%s\n", user_date->atresp);
        }else
        {
            printf("[=============================]call_get_version_sync error, %s\n",callError->message);
        }

	printf("[%s]:will call Gvarient method:@@@@@@@=======@@@@@@\n", __func__);
	GVariant *atcommand_out = NULL;
	GVariant *atcommand_in = NULL;
	gint serviceid = 0;
	gint cid = 0;
	gint payloadlen = 0;
	gchar *atcommand_str = NULL;
	gchar *atresp = NULL;
	atcommand_in = g_variant_new("((ii)is)",1,2,0,"","");
	
	helper_com_fibocom_helper_call_send_mesg_sync(proxy,atcommand_in,&atcommand_out,NULL,&callError);
	if(callError == NULL)
        {
            g_variant_get(atcommand_out, "((ii)is)", &serviceid, &cid, &payloadlen, &atresp);
            printf("[=============================]call_atcommand_sync success:\nserviceid:%d, cid:%d, payloadlen:%d, atresp:%s\n",
            		serviceid, cid, payloadlen,atresp);
            if(atcommand_out != NULL)
            {
            	g_variant_unref(atcommand_out);
            	printf("====================================================================unref ok\n");
            }
            
        }else
        {
            printf("[=============================]call_atcommand_sync error, %s\n",callError->message);
        }

    }while(0);

}
void stack_trace(){
    void *trace[16];
    char **messages = (char **)NULL;
    int i, trace_size = 0;

    trace_size = backtrace(trace, 16);
    messages = backtrace_symbols(trace, trace_size);
    if(messages == NULL)
    {
        printf("%s: no backtrace captured\n", __func__);
        return;
    }
    
    printf("[stack trace]>>>\n");
    for(i=0; i < trace_size; i++)
    {
        if(messages[i])
            printf("%s\n", messages[i]);
    }
    
    printf("<<<[stack trace]\n");
    if(messages)
    {
        free(messages);
    }
}

static void sig_handler(int sig)
{
    printf("%s - Signal Received=%d", __func__, sig);

    if (SIGHUP == sig)
    {
        return;
    }
    else if(SIGSEGV == sig)
    {
        stack_trace();
    }
    exit(-1);
}

int main(int argc, char const *argv[])
{
    GError *connerror = NULL;
    GError *proxyerror = NULL;
    GDBusConnection *conn;
    GMainLoop *loop;
    GThread *gthread = NULL;
    
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = sig_handler;
    sigaction(SIGHUP, &sa, NULL);
    sigaction(SIGSTOP, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
    sigaction(SIGINT, &sa, NULL);
    loop = g_main_loop_new(NULL, FALSE);
    #if !GLIB_CHECK_VERSION(2,35,0)
    g_type_init();
    #endif
    
    conn = g_bus_get_sync(G_BUS_TYPE_SESSION,NULL,&connerror);

    if(connerror != NULL)
    {
        printf("g_bus_get_sync connect error! %s \n",connerror->message);
        g_error_free(connerror);
        return 0;
    }

    proxy = helper_com_fibocom_helper_proxy_new_sync(conn,G_DBUS_PROXY_FLAGS_NONE,"com.fibocom.helper","/com/fibocom/helper",NULL,&proxyerror);

    if(proxy == NULL)
    {
        printf("helper_com_fibocom_helper_proxy_new_sync error! %s \n",proxyerror->message);
        g_error_free(proxyerror);
        return 0;
    }
    //注册signal处理函数
    g_signal_connect(proxy,"modem-status",G_CALLBACK(modem_status_handler),NULL);
    g_signal_connect(proxy,"service-status",G_CALLBACK(service_status_handler),NULL);
    GThread *gthread1 = NULL;
    atcommand at;
    atcommand *pat = &at;
    gthread = g_thread_new("helper",mythread,"Creat Threads!");
    strcpy(at.command,"AT+GTPKGVER?");
    at.atresp = NULL;
    gthread1 = g_thread_new("helper1", processthread, pat);

    
    loop = g_main_loop_new(NULL, FALSE);
    
    g_main_loop_run(loop);
    g_thread_join(gthread);

    g_object_unref(proxy);

    return 0;
}
