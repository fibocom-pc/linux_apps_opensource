#include <gio/gio.h>
#include <stdio.h>
#include "FibocomHelper.h"
#include <stdio.h>
#include <libudev.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <asm/types.h>
//该头文件需要放在netlink.h前面防止编译出现__kernel_sa_family未定义
#include <sys/socket.h>  
#include <linux/netlink.h>
#define UEVENT_BUFFER_SIZE 2048
static helperComFibocomHelper* skeleton=NULL;
/* 参数定义 */
typedef struct
{
	int 	state;
	char    path[256];
} modem;

/* 全局变量 */
static  pthread_mutex_t mutex;
static modem Modem = {0,"","ERROR"};
//setVersion方法的处理函数
static gboolean on_handle_set_version(helperComFibocomHelper* skeleton,GDBusMethodInvocation *invocation,const gchar *str,gpointer user_data)
{
    printf("Method call: %s\n", str);

    helper_com_fibocom_helper_complete_set_version (skeleton,invocation);

    return TRUE;
}

static gboolean on_handle_get_version(helperComFibocomHelper* skeleton,GDBusMethodInvocation *invocation,const gchar *str,gpointer user_data)
{
    printf("Method call: [%s]:%s\n", __func__, str);
    char out[1024] = {0};
    int ret  = send_at_command_for_port(str,out,"ttyUSB1");
    helper_com_fibocom_helper_complete_get_version (skeleton,invocation,out);

    return TRUE;
}
static gboolean on_handle_send_mesg(helperComFibocomHelper* skeleton,GDBusMethodInvocation *invocation,GVariant *str,gpointer user_data)
{
    printf("Method call: [%s]:%s\n", __func__, "AT COMMAND GVARIENT======@@@@@@");
    char out[1024] = {0};
    gchar *stratcommand = "AT+GTPKGVER?";  //AT COMMAND FOR CLIENT RESP
    gint  len = strlen(stratcommand);
    GVariant *atcommand = NULL;
    gint serviceid = 0;
    gint cid = 0;
    gint payloadlen = 0;
    gchar *atcommand_str = NULL;
    gchar *atresp = NULL;
    
    g_variant_get(str, "((ii)is)", &serviceid, &cid, &payloadlen, &atcommand_str);
    int ret  = send_at_command_for_port(stratcommand,out,"ttyUSB1");
    
    printf("[%s]:atcommand res:%s", __func__, out);
    atcommand = g_variant_new("((ii)is)",serviceid,cid,strlen(out),out);
    helper_com_fibocom_helper_complete_send_mesg (skeleton,invocation,atcommand);

    if(str != NULL)
    {
        printf("[%s]:will unref str(input)\n",__func__);
        //g_variant_unref(str);
    }
    return TRUE;
}
/**
 * 连接上bus daemon的回调
 **/
void on_bus_acquired (GDBusConnection *connection,const gchar *name,gpointer user_data)
{
    printf("on_bus_acquired has been invoked, name is %s\n", name);
    GError *error = NULL;
    skeleton = helper_com_fibocom_helper_skeleton_new();
    //注意方法名，需参照Hello.c里面生成的字符串
    g_signal_connect(skeleton,"handle-set-version",G_CALLBACK(on_handle_set_version),NULL);
    g_signal_connect(skeleton,"handle-get-version",G_CALLBACK(on_handle_get_version),NULL);
    g_signal_connect(skeleton,"handle-send-mesg",G_CALLBACK(on_handle_send_mesg),NULL);
    //发布服务到总线
    g_dbus_interface_skeleton_export(G_DBUS_INTERFACE_SKELETON(skeleton), connection, "/com/fibocom/helper", &error);
    if(error != NULL){                                                           
        printf("Error: Failed to export object. Reason: %s.\n", error->message);
        g_error_free(error);                                                    
    }
}

/**
 * 成功注册busName的回调
 **/
void on_bus_name_acquired (GDBusConnection *connection,const gchar *name,gpointer user_data)
{
    printf("on_bus_name_acquired has been invoked\n");
}

/**
 * busName丢失的回调，一般是server挂了？？
 **/
void on_bus_name_lost (GDBusConnection *connection,const gchar *name,gpointer user_data)
{
    printf("on_bus_name_lost !!!!\n");
}

/**
 * 测试发送信号函数，调用Hello.h自动生成的方法
 **/
static char status_value[128] = "Fibocom Helper send signal...";
static gboolean emit_modem_status_signal(const char* p)
{
    printf("emit_modem_status_signal invoked\n");
    if(skeleton != NULL)
    {
        if(p == NULL)
        {
            helper_com_fibocom_helper_emit_modem_status(skeleton,(const char*)status_value);
        }
        else
        {
            printf("[%s]:Modemstate changed!\n", __func__);
            helper_com_fibocom_helper_emit_modem_status(skeleton,(const char*)p);
        }
    }
    //status_value++;
    return FALSE;
}

static gboolean emit_service_status_signal(const char* p)
{
    printf("emit_service_service_signal invoked\n");
    if(skeleton != NULL)
    {
            printf("[%s]:check module is exit?\n", __func__);
            //FILE *fp = popen("lsusb | grep 413c:8213 | awk -F ' ' '{print $6}'| tr -d '\\n'","r");
            FILE *fp = popen("lspci | grep '4d75' | awk -F ' ' '{print $8}'| tr -d '\\n'","r");
            char resp[1024] = {0};
            if(fp != NULL)
            {
            	while(fgets(resp, 1024, fp) != NULL);
            	pclose(fp);
                helper_com_fibocom_helper_emit_service_status(skeleton,resp);
            }
            else
            {
                printf("[%s]:resp==================NULL======================= is\n",__func__);
		helper_com_fibocom_helper_emit_service_status(skeleton,"NOT EXIT");
            }
    }
    return TRUE;
}
void stack_trace(){
    void *trace[16];
    char **messages = (char **)NULL;
    int i, trace_size = 0;

    trace_size = backtrace(trace, 16);
    messages = backtrace_symbols(trace, trace_size);
    if(messages == NULL)
    {
        printf("%s: no backtrace captured\n", __func__);
        return;
    }
    
    printf("[stack trace]>>>\n");
    for(i=0; i < trace_size; i++)
    {
        if(messages[i])
            printf("%s\n", messages[i]);
    }
    
    printf("<<<[stack trace]\n");
    if(messages)
    {
        free(messages);
    }
}

static void sig_handler(int sig)
{
    printf("%s - Signal Received=%d\n", __func__, sig);

    if (SIGHUP == sig)
    {
        return;
    }
    else if(SIGSEGV == sig)
    {
        stack_trace();
    }
    else if(sig == SIGINT)
    {
        printf("%s - Signal Received=%d,emit_service_status_signal will call\n", __func__, sig);
    }
    
    exit(-1);
}

void listen_modem(void *str)
{
 struct sockaddr_nl client;
    struct timeval tv;
    int fd, rcvlen, ret;
    fd_set fds;
    int buffersize = 1024;

    fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_KOBJECT_UEVENT);
    memset(&client, 0, sizeof(client));

    client.nl_family = AF_NETLINK;
    client.nl_pid = getpid();
    client.nl_groups = 1; /* receive broadcast message*/

    setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &buffersize, sizeof(buffersize));
    bind(fd, (struct sockaddr*)&client, sizeof(client));

    while (1) {
        char buf[UEVENT_BUFFER_SIZE] = { 0 };
        FD_ZERO(&fds);
        FD_SET(fd, &fds);
        tv.tv_sec = 0;
        tv.tv_usec = 100 * 1000;

        ret = select(fd + 1, &fds, NULL, NULL, &tv);
        if(ret < 0)
            continue;

        if(!(ret > 0 && FD_ISSET(fd, &fds)))
            continue;

        /* receive data */
        rcvlen = recv(fd, &buf, sizeof(buf), 0);
        if (rcvlen > 0) {
            printf("%s\n", buf);
            /*You can do something here to make the program more perfect!!!*/
        }
    }
    close(fd);
}

/* 检测usb设备 */
int UsbCheck(void)
{
#if 1
	/* 初始化udev */
        char *devicepath = NULL;
	struct udev *udev = udev_new();
	if(!udev)
	{
        printf("Failed to initialize libudev.\n");
        return -1;
	}

	/* 创建monitor */
    struct udev_monitor *monitor = udev_monitor_new_from_netlink(udev, "udev");
    if (!monitor)
	{
        printf("Failed to create udev monitor.\n");
        udev_unref(udev);
        return -1;
    }
    printf("[%s]:enter func.\n",__func__);
    /* 监听usb的事件 */
    udev_monitor_filter_add_match_subsystem_devtype(monitor, "usb", NULL);
    udev_monitor_enable_receiving(monitor);
      printf("[%s]:enter func.----------\n",__func__);
	/* 循环监听事件 */
    while (1)
    {
        struct udev_device *device = udev_monitor_receive_device(monitor);
        if (device)
	{
	    const char *action = udev_device_get_action(device);
            const char *devnode = udev_device_get_devnode(device);
            if (action && devnode)
	    {

	        printf("[%s]:enter action.\n",__func__);
	        int sta = 0;
	        char path[256] = {0};
	        int path_id;
	        if(0 == strcmp(action, "add"))
	        {
	            sta = 1;
	            printf("[%s]:enter add.\n",__func__);
	            printf(" VID/PID: %s %s\n",udev_device_get_sysattr_value(device,"idVendor"),udev_device_get_sysattr_value(device, "idProduct"));

	            printf(" %s\n %s\n",udev_device_get_sysattr_value(device,"manufacturer"),udev_device_get_sysattr_value(device,"product"));
	            printf(" serial: %s\n",udev_device_get_sysattr_value(device, "serial"));
	            if(strstr(udev_device_get_sysattr_value(device,"product"), "FM101") != NULL)
	            {   
	                printf("[%s]:====== FM101 is add\n");
	                emit_modem_status_signal("[ModemState]FM101 added");
	                sprintf(Modem.path, "%s", devnode);
	            }
	        }
	        else if(0 == strcmp(action, "remove"))
	        {
	            printf("[%s]:enter remove.\n",__func__);
	            sprintf(path, "%s", "Removed");
	            sta = 0;
	            if(strcmp(Modem.path,devnode) == 0)
	            {
	                emit_modem_status_signal("[ModemState]FM101 removed");
	                printf("[%s]:enter remove FM101.\n",__func__);
	                sprintf(Modem.path, "%s", "ERROR");
	            }  
	        }

	        /* 加锁赋值 */
	        pthread_mutex_lock(&mutex);
	        Modem.state = sta;
	        //sprintf(Modem.pruduct, "%s", path);
	        pthread_mutex_unlock(&mutex);
            }
            udev_device_unref(device);
        }
    }

    udev_monitor_unref(monitor);
    udev_unref(udev);
    #endif
}

int main(int argc, char const *argv[])
{
    guint owner_id;
    GMainLoop *loop;
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    
    GThread *gthread1 = NULL;
    //GThread *gthread = NULL;
    //gthread = g_thread_new("listModem", listen_modem, NULL);
    gthread1 = g_thread_new("listenModem", UsbCheck, NULL);
    sa.sa_handler = sig_handler;
    sigaction(SIGHUP, &sa, NULL);
    sigaction(SIGSTOP, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
    sigaction(SIGINT, &sa, NULL);
    
    
    #if !GLIB_CHECK_VERSION(2,35,0)
    g_type_init();
    #endif//G_BUS_TYPE_SESSION
    owner_id = g_bus_own_name(G_BUS_TYPE_SESSION,"com.fibocom.helper",
                              G_BUS_NAME_OWNER_FLAGS_NONE,
                              on_bus_acquired,on_bus_name_acquired,on_bus_name_lost,NULL,NULL);

    //测试，每3s发一次signal
    g_timeout_add(3000,(GSourceFunc)emit_service_status_signal, NULL);
    //主线程进入循环
    loop = g_main_loop_new(NULL, FALSE);
    g_main_loop_run(loop);

    g_bus_unown_name(owner_id);

    return 0;
}
